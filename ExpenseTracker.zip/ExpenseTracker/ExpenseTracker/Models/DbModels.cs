﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using static ExpenseTracker.Models.Validation;

namespace ExpenseTracker.Models
{
    public class Category
    {
        public Category()
        {
            this.Expenses =new List<Expense>();
        }
        public int CategoryId { get; set; }
        [Display(Name = "Category Name")]
        public string CategoryName { get; set; }
        public virtual ICollection<Expense> Expenses { get; set; }
    }

    public class Expense
    {
        
        public int ExpenseId { get; set; }
        [Required, Column(TypeName = "date"), Display(Name = "Expense Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [ExpenseDateValidation(ErrorMessage = "Expense Date must be today or less than today...")]
        public DateTime ExpenseDate { get; set; }
        [Required, Display(Name = "Expense Amount")]
        public decimal ExpenseAmount { get; set; }

        //FK
        [ForeignKey("Category")]
        public int CategoryId { get; set; }

        public virtual Category Category { get; set; }
    }
    public class ExpenseDbContext : DbContext
    {

        public ExpenseDbContext(DbContextOptions<ExpenseDbContext> options) : base(options)
        {

        }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Expense> Expenses { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<Category>(entity => {
                entity.HasIndex(e => e.CategoryName).IsUnique();
            });
        }
    }
}
